
LABEL_KEY = 'Strength'
NUMERICAL_FEATURES = ['Cement','Water', 'Blast Furnace Slag','Fly Ash','Water', 'Superplasticizer','Coarse Aggregate','Fine Aggregate','Age']


def t_name(key):
    return key + '_xf'
